# WORLD NEXUS - Development Documentation

## Architecture Overview

WORLD NEXUS follows a component-based architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────┐
│              App.tsx (Router)                   │
├─────────────────────────────────────────────────┤
│  Navigation  │  Hero  │  ContentPillars  │ Footer
├─────────────────────────────────────────────────┤
│         Reusable UI Components (shadcn/ui)      │
├─────────────────────────────────────────────────┤
│    Tailwind CSS + Custom Theme Variables        │
└─────────────────────────────────────────────────┘
```

## Component Documentation

### Navigation Component (`components/Navigation.tsx`)

**Purpose**: Sticky header navigation with responsive mobile menu

**Props**: None (uses internal state)

**Key Features**:
- Sticky positioning with glassmorphism backdrop blur
- Responsive mobile hamburger menu
- Smooth hover animations with gradient underlines
- Logo with gradient background
- Navigation dividers between menu items

**Usage**:
```tsx
import Navigation from '@/components/Navigation';

export default function Layout() {
  return <Navigation />;
}
```

**Customization**:
- Edit `navItems` array to change menu items
- Modify colors by updating CSS variables
- Adjust animation duration in transition classes

### Hero Component (`components/Hero.tsx`)

**Purpose**: Full-screen hero section with rotating philosophical quotes

**Props**: None (uses internal state)

**Key Features**:
- Rotating quote carousel (6-second intervals)
- Smooth fade transitions between quotes
- Interactive quote indicator dots
- Layered background with gradient overlays
- Animated scroll indicator
- Call-to-action buttons

**State Management**:
```tsx
const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
const [isTransitioning, setIsTransitioning] = useState(false);
```

**Quote Structure**:
```tsx
{
  text: "Quote text here",
  author: "Author Name",
  theme: "innovation" | "history" | "technology" | "philosophy" | "wisdom"
}
```

**Customization**:
- Edit `PHILOSOPHICAL_QUOTES` array to add/remove quotes
- Change rotation interval: modify `6000` (milliseconds) in useEffect
- Update background image URL in style prop

### ContentPillar Component (`components/ContentPillar.tsx`)

**Purpose**: Reusable section component for the four content pillars

**Props**:
```tsx
interface ContentPillarProps {
  id: string;                          // Section ID for routing
  title: string;                       // Section title
  subtitle: string;                    // Section subtitle/label
  backgroundImage: string;             // Background image URL
  accentColor: 'cyan' | 'crimson' | 'gold'; // Accent color
  content: {
    introduction: string;              // Intro paragraph
    mainText: string;                  // Main reading content
    keyTakeaway: string;               // Blockquote takeaway
  };
  videoPlaceholder?: {
    title: string;                     // Video title
    description: string;               // Video description
  };
}
```

**Key Features**:
- Glassmorphism card design
- Web-book reading layout
- Video placeholder with play button
- Community engagement section
- Comment form with preview
- Responsive grid layout (1 column mobile, 3 columns desktop)

**Usage**:
```tsx
<ContentPillar
  id="international-news"
  title="International News & Geopolitics"
  subtitle="Global Affairs"
  backgroundImage="https://..."
  accentColor="cyan"
  content={{
    introduction: "...",
    mainText: "...",
    keyTakeaway: "..."
  }}
  videoPlaceholder={{
    title: "Video Title",
    description: "Video description"
  }}
/>
```

**Accent Color Mapping**:
- `cyan`: #00d9ff (Technology/Innovation)
- `crimson`: #8b1a1a (Historical/Political)
- `gold`: #d4af37 (Philosophical/Spiritual)

### Newsletter Component (`components/Newsletter.tsx`)

**Purpose**: Email subscription form with success state

**Props**: None (uses internal state)

**Key Features**:
- Email input validation
- Success state animation
- Subscription statistics display
- Glassmorphism design
- Collaboration contact information

**State Management**:
```tsx
const [email, setEmail] = useState('');
const [isSubscribed, setIsSubscribed] = useState(false);
const [isLoading, setIsLoading] = useState(false);
```

**Customization**:
- Replace `handleSubscribe` function with actual API call
- Update success message duration (currently 3 seconds)
- Modify statistics display

### Footer Component (`components/Footer.tsx`)

**Purpose**: Multi-column footer with navigation and contact information

**Props**: None

**Key Features**:
- Four-column layout (Brand, Content, Resources, Connect)
- Social media links
- Collaboration contact information
- Copyright notice
- Responsive grid layout

**Customization**:
- Update footer links in column sections
- Add/remove social media icons
- Modify copyright year (auto-calculated)

## Theme System

### Color Variables

All colors are defined in `client/src/index.css` as CSS custom properties:

```css
:root {
  /* Primary Colors */
  --primary: #00d9ff;                /* Neon cyan - Tech/Innovation */
  --primary-foreground: #0f1a2e;     /* Deep indigo */
  
  /* Secondary Colors */
  --secondary: #8b1a1a;              /* Crimson - History/Politics */
  --secondary-foreground: #f5f5f5;   /* Bright white */
  
  /* Accent Colors */
  --accent: #d4af37;                 /* Gold - Philosophy/Spirituality */
  --accent-foreground: #0f1a2e;      /* Deep indigo */
  
  /* Semantic Colors */
  --background: #0f1a2e;             /* Deep indigo background */
  --foreground: #f5f5f5;             /* Bright white text */
  --card: #1a2f4a;                   /* Card background */
  --card-foreground: #f5f5f5;        /* Card text */
  --muted: #2a3f5a;                  /* Muted elements */
  --muted-foreground: #a0a0a0;       /* Muted text */
  --border: #2a3f5a;                 /* Border color */
  --input: #1a2f4a;                  /* Input background */
  --ring: #00d9ff;                   /* Focus ring */
}
```

### Typography System

```css
h1, h2, h3, h4, h5, h6 {
  font-family: 'Space Mono', monospace;  /* Display font */
  font-weight: 700;
  letter-spacing: -0.02em;
}

body {
  font-family: 'Lato', sans-serif;       /* Body font */
}

code, pre {
  font-family: 'IBM Plex Mono', monospace; /* Code font */
}
```

### Font Sizes

- h1: 3rem (48px)
- h2: 2.25rem (36px)
- h3: 1.875rem (30px)
- h4: 1.5rem (24px)
- body: 1rem (16px)
- small: 0.875rem (14px)
- xs: 0.75rem (12px)

## Animation System

### Transitions

All transitions use custom easing functions for smooth, natural motion:

```css
/* Snappy ease-out for UI elements */
transition: all 300ms cubic-bezier(0.23, 1, 0.32, 1);

/* Smooth ease-in-out for morphing */
transition: all 250ms cubic-bezier(0.77, 0, 0.175, 1);
```

### Keyframe Animations

- `fade-in`: Opacity from 0 to 1
- `slide-in-from-top`: Slide down with fade
- `slide-in-from-bottom`: Slide up with fade
- `bounce`: Vertical bounce effect
- `pulse`: Subtle opacity pulse

### Hover Effects

- Buttons: `scale(0.97)` on active, `scale(1.02)` on hover
- Links: Gradient underline animation
- Cards: Border color change, shadow increase
- Icons: Color transition to primary

## State Management

The project uses React's built-in hooks for state management:

- `useState`: Component-level state
- `useEffect`: Side effects and lifecycle
- `useContext`: Theme context for dark mode

### Example: Quote Rotation in Hero

```tsx
useEffect(() => {
  const interval = setInterval(() => {
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentQuoteIndex((prev) => (prev + 1) % PHILOSOPHICAL_QUOTES.length);
      setIsTransitioning(false);
    }, 300);
  }, 6000);

  return () => clearInterval(interval);
}, []);
```

## Routing

The project uses Wouter for lightweight client-side routing:

```tsx
// App.tsx
<Switch>
  <Route path="/" component={Home} />
  <Route path="/404" component={NotFound} />
  <Route component={NotFound} /> {/* Fallback */}
</Switch>
```

### Navigation

```tsx
import { Link } from 'wouter';

<Link href="/international-news">
  <a>International News</a>
</Link>
```

## Performance Considerations

### Code Splitting

The project uses Vite's automatic code splitting. For manual chunks:

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor': ['react', 'react-dom'],
          'ui': ['@/components/ui']
        }
      }
    }
  }
})
```

### Image Optimization

- Use `.webp` format for modern browsers
- Provide `.png` fallbacks for older browsers
- Compress images before deployment
- Use appropriate dimensions (avoid oversized images)

### Bundle Analysis

```bash
# Install bundle analyzer
pnpm add -D rollup-plugin-visualizer

# Generate bundle report
pnpm build
```

## Testing Strategy

### Unit Tests (Future)

```tsx
// Example test structure
import { render, screen } from '@testing-library/react';
import Navigation from '@/components/Navigation';

describe('Navigation', () => {
  it('renders navigation items', () => {
    render(<Navigation />);
    expect(screen.getByText('Home')).toBeInTheDocument();
  });
});
```

### E2E Tests (Future)

```typescript
// Example Playwright test
test('hero quote rotates', async ({ page }) => {
  await page.goto('/');
  const quote = page.locator('blockquote');
  const initialText = await quote.textContent();
  
  await page.waitForTimeout(6000);
  const newText = await quote.textContent();
  
  expect(newText).not.toBe(initialText);
});
```

## Common Patterns

### Conditional Rendering

```tsx
{isSubscribed ? (
  <SuccessMessage />
) : (
  <SubscriptionForm />
)}
```

### Smooth Scroll Navigation

```tsx
const handleScroll = (id: string) => {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
};
```

### Responsive Classes

```tsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
  {/* Responsive grid: 1 col mobile, 2 cols tablet, 3 cols desktop */}
</div>
```

### Glassmorphism Effect

```tsx
<div className="bg-card/50 backdrop-blur-md border border-border rounded-lg">
  {/* Semi-transparent background with blur effect */}
</div>
```

## Debugging

### Browser DevTools

1. **React DevTools**: Inspect component tree and props
2. **Network Tab**: Monitor API calls and asset loading
3. **Console**: Check for errors and warnings
4. **Performance Tab**: Profile rendering performance

### Vite Debug Mode

```bash
# Start dev server with debug logging
DEBUG=* pnpm dev
```

### TypeScript Checking

```bash
# Check for type errors
pnpm check

# Watch mode
pnpm check --watch
```

## Best Practices

### Component Organization

- Keep components focused and single-responsibility
- Use composition over inheritance
- Extract reusable logic into custom hooks
- Maintain consistent naming conventions

### Styling

- Use Tailwind utilities for consistency
- Avoid inline styles (use CSS classes)
- Leverage CSS variables for theming
- Use semantic color names (primary, secondary, etc.)

### Performance

- Lazy load images and components
- Minimize re-renders with proper dependencies
- Use React.memo for expensive components
- Optimize bundle size with code splitting

### Accessibility

- Use semantic HTML elements
- Provide alt text for images
- Ensure keyboard navigation
- Maintain color contrast ratios
- Test with screen readers

### Code Quality

- Follow ESLint rules
- Format code with Prettier
- Write meaningful variable names
- Add comments for complex logic
- Keep functions small and focused

## Future Enhancements

1. **Backend Integration**: Add database for comments and subscriptions
2. **User Authentication**: Implement user accounts and profiles
3. **Search Functionality**: Add full-text search across articles
4. **Dark/Light Theme Toggle**: Allow users to switch themes
5. **Progressive Web App**: Add offline support and installability
6. **Multi-language Support**: Internationalization (i18n)
7. **Advanced Analytics**: Track user engagement and content performance
8. **Content Management System**: Admin dashboard for content management
9. **Social Sharing**: Add share buttons for articles
10. **Related Articles**: Recommend similar content

## Troubleshooting Guide

### Issue: Styles not applying

**Solution**: 
1. Verify CSS file is imported in main.tsx
2. Check Tailwind configuration
3. Clear browser cache (Cmd+Shift+Delete)
4. Restart dev server

### Issue: Images not loading

**Solution**:
1. Verify image URL is correct
2. Check CORS headers
3. Use .webp format with .png fallback
4. Ensure image path is absolute URL

### Issue: Build fails

**Solution**:
1. Clear node_modules: `rm -rf node_modules`
2. Clear Vite cache: `rm -rf dist`
3. Reinstall: `pnpm install`
4. Check Node version: `node --version`

### Issue: Hot reload not working

**Solution**:
1. Restart dev server: `pnpm dev`
2. Check file paths are correct
3. Verify file is in src directory
4. Check for syntax errors

## Resources

- [React Documentation](https://react.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)
- [Vite Documentation](https://vitejs.dev)
- [Wouter Documentation](https://github.com/molefrog/wouter)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)
