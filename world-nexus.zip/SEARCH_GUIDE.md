# WORLD NEXUS - Search System Guide

## Overview

The WORLD NEXUS search system provides a powerful, real-time keyword filtering engine that searches across all published articles. The search is fully client-side, meaning it works instantly without server requests, and it indexes all article metadata including titles, content, authors, and categories.

## Features

### 1. Search Bar Location
The search icon (magnifying glass) is located in the top navigation bar, next to the WORLD NEXUS logo. Click it to activate the search interface.

### 2. Live Keyword Filtering
As you type, the search engine instantly filters articles matching your keywords. Results update in real-time with no lag or delay.

### 3. Search Scope
The search engine indexes:
- **Article Titles**: Primary search target with highest relevance
- **Article Excerpts**: Summary text with high relevance
- **Article Content**: Full body text with medium relevance
- **Author Names**: Author metadata with lower relevance
- **Categories**: Article categories with lowest relevance

### 4. Relevance Ranking
Search results are automatically ranked by relevance:
1. **Title Matches** (100 points): Keywords found in article title
2. **Excerpt Matches** (80 points): Keywords in article summary
3. **Author Matches** (60 points): Keywords in author name
4. **Category Matches** (40 points): Keywords in category name
5. **Content Matches** (20 points): Keywords in article body

**Bonus Points**:
- +50 points if match is at the beginning of text
- +25 points if match is in first 50 characters
- +30 points for exact word boundary matches

## How to Use

### Basic Search

1. **Click the Search Icon**: Located in the top navigation bar (magnifying glass icon)
2. **Type Your Keyword**: Enter any word or phrase you want to search for
3. **View Results**: Results appear instantly as you type
4. **Select a Result**: Click on any result to view the full article

### Search Examples

**Example 1: Search by Topic**
- Type: `"Middle East"`
- Results: All articles mentioning Middle East conflicts and geopolitics

**Example 2: Search by Religious Topic**
- Type: `"Council of Nicaea"`
- Results: Articles about the historical Council of Nicaea

**Example 3: Search by Author**
- Type: `"WORLD NEXUS Editorial"`
- Results: All articles by the WORLD NEXUS Editorial team

**Example 4: Search by Technology**
- Type: `"artificial intelligence"`
- Results: All AI and technology-related articles

**Example 5: Search by Concept**
- Type: `"financial systems"`
- Results: Articles about economics, money, and finance

### Category Filtering

After searching, you can filter results by category:
- **All Categories**: Show all matching articles
- **International News & Geopolitics**: Filter to geopolitics articles
- **Religions & Traditional Perspectives**: Filter to religion/philosophy articles
- **Global Politics & Finance**: Filter to economics/politics articles
- **The Daily AI Revolution & Tech Automation**: Filter to AI/tech articles

## Search Results Page

### Layout
The search results page displays:
- **Search Query**: Shows what you searched for
- **Result Count**: Total number of matching articles
- **Article Cards**: Each result shows:
  - Article title
  - Category badge
  - Excerpt/preview text
  - Author name
  - Publication date
  - Match type indicator (Title/Summary/Content Match)
  - Video indicator (if article includes video)

### Match Type Indicators
- **Title Match**: Keyword found in article title (highest relevance)
- **Summary Match**: Keyword found in article excerpt
- **Author Match**: Keyword found in author name
- **Content Match**: Keyword found in article body

### No Results
If no articles match your search:
- A "No Results Found" message appears
- Suggestions for refining your search are provided
- You can try different keywords or broader terms

## Advanced Features

### Multi-Word Search
You can search for multiple words:
- Type: `"AI automation employment"`
- Results: Articles containing any of these words

### Partial Word Matching
The search engine supports partial word matching:
- Type: `"tech"` finds "technology", "technical", "tech"
- Type: `"finance"` finds "financial", "financing", "finance"

### Case-Insensitive Search
Search is not case-sensitive:
- `"COUNCIL"` = `"council"` = `"Council"`
- All variations return the same results

### Real-Time Updates
When you publish new articles through the Admin Dashboard:
- They are immediately searchable
- No page refresh required
- Search index updates automatically

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Click Search Icon` | Open search interface |
| `Type` | Search in real-time |
| `Esc` | Close search panel |
| `Backspace` | Delete character and update results |
| `Enter` | Navigate to full search results page |

## Search Performance

### Speed
- **Instant**: Results appear as you type (< 50ms delay)
- **No Server Requests**: All processing happens in your browser
- **Optimized**: Efficient algorithm for fast filtering

### Accuracy
- **Comprehensive**: Searches all article fields
- **Relevant**: Results ranked by relevance score
- **Flexible**: Supports partial matches and variations

## Troubleshooting

### Search Not Working
**Problem**: Search icon doesn't respond

**Solutions**:
1. Refresh the page
2. Clear browser cache
3. Try a different browser
4. Check browser console for errors (F12)

### No Results Found
**Problem**: Search returns no results for a keyword you know exists

**Solutions**:
1. Check spelling of your search term
2. Try a shorter or more general keyword
3. Try searching for a different word from the article
4. Verify the article was published successfully

### Search Results Outdated
**Problem**: New articles don't appear in search

**Solutions**:
1. Refresh the page
2. Search index updates automatically
3. Wait a few seconds and try again
4. Check that article was published to correct category

### Slow Search Performance
**Problem**: Search is slow or laggy

**Solutions**:
1. Close other browser tabs
2. Clear browser cache
3. Reduce number of articles (delete old ones)
4. Try a more specific search term

## Technical Details

### Search Algorithm
The search system uses:
- **Linear Search**: Scans all articles for matches
- **Relevance Scoring**: Ranks results by relevance
- **Position Weighting**: Boosts early matches
- **Word Boundary Detection**: Finds exact word matches

### Data Indexed
Search indexes:
- Article title
- Article excerpt (auto-generated)
- Article content (full text)
- Author name
- Category name
- Article metadata

### Search Scope
- **Local Storage**: All articles stored in browser
- **Real-Time**: Updates instantly when articles change
- **Client-Side**: No server communication required

### Performance Metrics
- **Search Time**: < 50ms for typical queries
- **Index Size**: ~10-50KB depending on article count
- **Memory Usage**: Minimal (< 1MB for 100 articles)

## Best Practices

### Effective Searching

**Do**:
- Use specific keywords (e.g., "Council of Nicaea" instead of "church")
- Search for unique terms that appear in fewer articles
- Use author names to find articles by specific contributors
- Combine multiple searches to narrow results

**Don't**:
- Use very common words (e.g., "the", "and", "is")
- Search for single letters
- Use special characters or symbols
- Expect exact phrase matching (search is word-based)

### Publishing for Searchability

When creating articles:
- Use descriptive, keyword-rich titles
- Include relevant keywords in the first paragraph
- Use clear author attribution
- Select appropriate categories
- Write comprehensive content

## Future Enhancements

Planned search features:
- **Advanced Filters**: Filter by date range, author, category
- **Search History**: Remember recent searches
- **Saved Searches**: Save favorite searches
- **Search Analytics**: Track popular search terms
- **Autocomplete**: Suggest search terms as you type
- **Fuzzy Matching**: Handle typos and misspellings
- **Full-Text Indexing**: Dedicated search index for speed
- **Multi-Language Support**: Search in multiple languages

## API Reference

### useSearch Hook

```typescript
import { useSearch } from '@/contexts/SearchContext';

const {
  searchQuery,           // Current search query string
  setSearchQuery,        // Update search query
  isSearchOpen,          // Whether search panel is open
  setIsSearchOpen,       // Toggle search panel
  searchResults,         // Array of matching articles
  totalResults,          // Count of matching articles
  selectedCategory,      // Currently selected category filter
  setSelectedCategory,   // Update category filter
  clearSearch,           // Clear search and close panel
} = useSearch();
```

### SearchResult Type

```typescript
interface SearchResult extends Article {
  matchType: 'title' | 'excerpt' | 'content' | 'author' | 'category';
  relevanceScore: number;  // 0-200+ points
}
```

## Support

For issues or questions about search:
- **Email**: contact@worldnexushistory.com
- **Website**: worldnexushistory.com

## Version History

- **v1.0.0** (May 2026): Initial search system release
  - Live keyword filtering
  - Relevance ranking
  - Category filtering
  - Real-time updates
  - Mobile-responsive interface
