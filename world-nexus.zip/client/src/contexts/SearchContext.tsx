import React, { createContext, useContext, useState, useMemo } from 'react';
import { useArticles } from './ArticleContext';
import { Article, ArticleCategory } from '@/types/article';

/**
 * Search Context
 * Manages search state and implements live keyword filtering
 * Searches across article titles, excerpts, content, and metadata
 */

interface SearchResult extends Article {
  matchType: 'title' | 'excerpt' | 'content' | 'author' | 'category';
  relevanceScore: number;
}

interface SearchContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  searchResults: SearchResult[];
  totalResults: number;
  selectedCategory: ArticleCategory | 'all' | null;
  setSelectedCategory: (category: ArticleCategory | 'all' | null) => void;
  clearSearch: () => void;
}

const SearchContext = createContext<SearchContextType | undefined>(undefined);

export function SearchProvider({ children }: { children: React.ReactNode }) {
  const { articles } = useArticles();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ArticleCategory | 'all' | null>(null);

  // Calculate relevance score based on match type and position
  const calculateRelevance = (text: string, query: string, matchType: string): number => {
    const lowerText = text.toLowerCase();
    const lowerQuery = query.toLowerCase();
    const index = lowerText.indexOf(lowerQuery);

    // Base scores by match type
    const baseScores: Record<string, number> = {
      title: 100,
      excerpt: 80,
      author: 60,
      category: 40,
      content: 20,
    };

    const baseScore = baseScores[matchType] || 0;

    // Boost score if match is at the beginning
    const positionBoost = index === 0 ? 50 : index < 50 ? 25 : 0;

    // Boost score if it's an exact word match
    const wordBoundary = new RegExp(`\\b${query}\\b`, 'i');
    const exactMatchBoost = wordBoundary.test(text) ? 30 : 0;

    return baseScore + positionBoost + exactMatchBoost;
  };

  // Perform search with relevance ranking
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) {
      return [];
    }

    const query = searchQuery.trim();
    const results: SearchResult[] = [];
    const seenArticleIds = new Set<string>();

    articles.forEach((article) => {
      // Filter by category if selected
      if (selectedCategory && selectedCategory !== 'all' && article.category !== selectedCategory) {
        return;
      }

      let maxRelevance = 0;
      let matchType: 'title' | 'excerpt' | 'content' | 'author' | 'category' = 'content';

      // Search in title
      if (article.title.toLowerCase().includes(query.toLowerCase())) {
        const relevance = calculateRelevance(article.title, query, 'title');
        if (relevance > maxRelevance) {
          maxRelevance = relevance;
          matchType = 'title';
        }
      }

      // Search in excerpt
      if (article.excerpt && article.excerpt.toLowerCase().includes(query.toLowerCase())) {
        const relevance = calculateRelevance(article.excerpt, query, 'excerpt');
        if (relevance > maxRelevance) {
          maxRelevance = relevance;
          matchType = 'excerpt';
        }
      }

      // Search in content
      if (article.content.toLowerCase().includes(query.toLowerCase())) {
        const relevance = calculateRelevance(article.content, query, 'content');
        if (relevance > maxRelevance) {
          maxRelevance = relevance;
          matchType = 'content';
        }
      }

      // Search in author
      if (article.author.toLowerCase().includes(query.toLowerCase())) {
        const relevance = calculateRelevance(article.author, query, 'author');
        if (relevance > maxRelevance) {
          maxRelevance = relevance;
          matchType = 'author';
        }
      }

      // Only add if there's a match and we haven't seen this article
      if (maxRelevance > 0 && !seenArticleIds.has(article.id)) {
        results.push({
          ...article,
          matchType,
          relevanceScore: maxRelevance,
        });
        seenArticleIds.add(article.id);
      }
    });

    // Sort by relevance score (highest first)
    return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
  }, [searchQuery, articles, selectedCategory]);

  const clearSearch = () => {
    setSearchQuery('');
    setIsSearchOpen(false);
    setSelectedCategory(null);
  };

  const value: SearchContextType = {
    searchQuery,
    setSearchQuery,
    isSearchOpen,
    setIsSearchOpen,
    searchResults,
    totalResults: searchResults.length,
    selectedCategory,
    setSelectedCategory,
    clearSearch,
  };

  return (
    <SearchContext.Provider value={value}>
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  const context = useContext(SearchContext);
  if (!context) {
    throw new Error('useSearch must be used within SearchProvider');
  }
  return context;
}
