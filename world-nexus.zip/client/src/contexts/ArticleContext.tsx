import React, { createContext, useContext, useState, useEffect } from 'react';
import { Article, ArticleFormData, ArticleCategory } from '@/types/article';
import { nanoid } from 'nanoid';

/**
 * Article Context
 * Manages article state with localStorage persistence
 * Provides CRUD operations for articles
 */

interface ArticleContextType {
  articles: Article[];
  addArticle: (formData: ArticleFormData) => Article;
  updateArticle: (id: string, formData: ArticleFormData) => boolean;
  deleteArticle: (id: string) => boolean;
  getArticleById: (id: string) => Article | undefined;
  getArticlesByCategory: (category: ArticleCategory) => Article[];
  clearAllArticles: () => void;
}

const ArticleContext = createContext<ArticleContextType | undefined>(undefined);

const STORAGE_KEY = 'world-nexus-articles';

// Default articles to seed the system
const DEFAULT_ARTICLES: Article[] = [
  {
    id: nanoid(),
    title: 'Understanding Middle East Geopolitics in 2026',
    category: 'international-news',
    content: 'The Middle East remains a critical region for global affairs. This article explores the complex dynamics between regional powers, international interventions, and the ongoing quest for stability and peace.',
    author: 'WORLD NEXUS Editorial',
    createdAt: new Date('2026-05-15'),
    updatedAt: new Date('2026-05-15'),
    excerpt: 'A comprehensive analysis of current geopolitical tensions in the Middle East.',
    featured: true,
  },
  {
    id: nanoid(),
    title: 'The Council of Nicaea: Shaping Christian Doctrine',
    category: 'religions',
    content: 'The Council of Nicaea (325 AD) was a pivotal moment in Christian history. This article examines how this council shaped Christian theology and its lasting impact on religious traditions.',
    author: 'WORLD NEXUS Editorial',
    createdAt: new Date('2026-05-10'),
    updatedAt: new Date('2026-05-10'),
    excerpt: 'Exploring the historical significance of the Council of Nicaea.',
    featured: true,
  },
  {
    id: nanoid(),
    title: 'Global Financial Systems and Economic Inequality',
    category: 'politics-finance',
    content: 'Modern financial systems shape global inequality. This article analyzes how monetary policy, trade agreements, and financial institutions influence economic outcomes worldwide.',
    author: 'WORLD NEXUS Editorial',
    createdAt: new Date('2026-05-08'),
    updatedAt: new Date('2026-05-08'),
    excerpt: 'Understanding the intersection of finance and social justice.',
  },
  {
    id: nanoid(),
    title: 'AI and the Future of Work: Opportunities and Challenges',
    category: 'ai-revolution',
    content: 'Artificial intelligence is transforming labor markets globally. This article explores how automation affects employment, skills development, and the social contract between workers and employers.',
    author: 'WORLD NEXUS Editorial',
    createdAt: new Date('2026-05-05'),
    updatedAt: new Date('2026-05-05'),
    excerpt: 'Examining AI\'s impact on employment and economic structures.',
    featured: true,
  },
];

export function ArticleProvider({ children }: { children: React.ReactNode }) {
  const [articles, setArticles] = useState<Article[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load articles from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        // Convert date strings back to Date objects
        const articlesWithDates = parsed.map((article: any) => ({
          ...article,
          createdAt: new Date(article.createdAt),
          updatedAt: new Date(article.updatedAt),
        }));
        setArticles(articlesWithDates);
      } catch (error) {
        console.error('Failed to parse stored articles:', error);
        // Fall back to default articles
        setArticles(DEFAULT_ARTICLES);
      }
    } else {
      // Initialize with default articles
      setArticles(DEFAULT_ARTICLES);
    }
    setIsLoaded(true);
  }, []);

  // Save articles to localStorage whenever they change
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
    }
  }, [articles, isLoaded]);

  const addArticle = (formData: ArticleFormData): Article => {
    const newArticle: Article = {
      id: nanoid(),
      ...formData,
      createdAt: new Date(),
      updatedAt: new Date(),
      excerpt: formData.content.substring(0, 150) + '...',
    };

    setArticles((prev) => [newArticle, ...prev]);
    return newArticle;
  };

  const updateArticle = (id: string, formData: ArticleFormData): boolean => {
    const articleIndex = articles.findIndex((a) => a.id === id);
    if (articleIndex === -1) return false;

    const updatedArticle: Article = {
      ...articles[articleIndex],
      ...formData,
      updatedAt: new Date(),
      excerpt: formData.content.substring(0, 150) + '...',
    };

    const newArticles = [...articles];
    newArticles[articleIndex] = updatedArticle;
    setArticles(newArticles);
    return true;
  };

  const deleteArticle = (id: string): boolean => {
    const filtered = articles.filter((a) => a.id !== id);
    if (filtered.length === articles.length) return false;
    setArticles(filtered);
    return true;
  };

  const getArticleById = (id: string): Article | undefined => {
    return articles.find((a) => a.id === id);
  };

  const getArticlesByCategory = (category: ArticleCategory): Article[] => {
    return articles.filter((a) => a.category === category);
  };

  const clearAllArticles = (): void => {
    setArticles([]);
    localStorage.removeItem(STORAGE_KEY);
  };

  const value: ArticleContextType = {
    articles,
    addArticle,
    updateArticle,
    deleteArticle,
    getArticleById,
    getArticlesByCategory,
    clearAllArticles,
  };

  return (
    <ArticleContext.Provider value={value}>
      {children}
    </ArticleContext.Provider>
  );
}

export function useArticles() {
  const context = useContext(ArticleContext);
  if (!context) {
    throw new Error('useArticles must be used within ArticleProvider');
  }
  return context;
}
