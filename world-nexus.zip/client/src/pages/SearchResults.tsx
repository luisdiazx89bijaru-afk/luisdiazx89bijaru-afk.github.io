import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Search, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import ArticleCard from '@/components/ArticleCard';
import { useSearch } from '@/contexts/SearchContext';
import { CATEGORY_LABELS, ArticleCategory } from '@/types/article';

/**
 * SearchResults Page
 * Displays filtered search results with category filtering
 * Shows real-time updates as search query changes
 */

export default function SearchResults() {
  const [, navigate] = useLocation();
  const {
    searchQuery,
    setSearchQuery,
    searchResults,
    totalResults,
    selectedCategory,
    setSelectedCategory,
  } = useSearch();

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleBack = () => {
    setSearchQuery('');
    setSelectedCategory(null);
    navigate('/');
  };

  const categoryOptions: Array<{ value: ArticleCategory | 'all'; label: string }> = [
    { value: 'all', label: 'All Categories' },
    { value: 'international-news', label: CATEGORY_LABELS['international-news'] },
    { value: 'religions', label: CATEGORY_LABELS['religions'] },
    { value: 'politics-finance', label: CATEGORY_LABELS['politics-finance'] },
    { value: 'ai-revolution', label: CATEGORY_LABELS['ai-revolution'] },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navigation />

      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 max-w-4xl space-y-8">
          {/* Header */}
          <div className="space-y-4">
            <Button
              onClick={handleBack}
              variant="outline"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Button>

            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Search className="w-8 h-8 text-primary" />
                <h1 className="text-4xl font-bold text-foreground">Search Results</h1>
              </div>
              {searchQuery && (
                <p className="text-lg text-muted-foreground">
                  Results for: <span className="text-primary font-semibold">"{searchQuery}"</span>
                </p>
              )}
            </div>
          </div>

          {/* Category Filter */}
          {searchQuery && (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-foreground">Filter by Category:</p>
              <div className="flex flex-wrap gap-2">
                {categoryOptions.map(({ value, label }) => (
                  <button
                    key={value}
                    onClick={() => setSelectedCategory(value === 'all' ? 'all' : value)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 text-sm ${
                      selectedCategory === value
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card/50 text-muted-foreground hover:text-foreground border border-border'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Results */}
          {searchQuery ? (
            <>
              {totalResults > 0 ? (
                <div className="space-y-6">
                  <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg">
                    <p className="text-sm text-foreground">
                      Found <span className="font-bold text-primary">{totalResults}</span> article
                      {totalResults !== 1 ? 's' : ''} matching your search
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {searchResults.map((article) => (
                      <div key={article.id} className="relative">
                        {/* Match Type Badge */}
                        <div className="absolute top-4 right-4 z-10">
                          <div className="px-2 py-1 bg-primary/20 text-primary text-xs font-semibold rounded border border-primary/40">
                            {article.matchType === 'title'
                              ? 'Title Match'
                              : article.matchType === 'excerpt'
                                ? 'Summary Match'
                                : article.matchType === 'author'
                                  ? 'Author Match'
                                  : 'Content Match'}
                          </div>
                        </div>
                        <ArticleCard article={article} />
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <Card className="bg-card/50 backdrop-blur-md border-border p-12 text-center space-y-4">
                  <Search className="w-12 h-12 text-muted-foreground mx-auto opacity-50" />
                  <div>
                    <h2 className="text-2xl font-bold text-foreground mb-2">No Results Found</h2>
                    <p className="text-muted-foreground">
                      We couldn't find any articles matching "<span className="font-semibold">{searchQuery}</span>"
                    </p>
                  </div>
                  <div className="pt-4">
                    <p className="text-sm text-muted-foreground mb-4">Try:</p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Using different keywords</li>
                      <li>• Checking your spelling</li>
                      <li>• Using more general terms</li>
                    </ul>
                  </div>
                </Card>
              )}
            </>
          ) : (
            <Card className="bg-card/50 backdrop-blur-md border-border p-12 text-center">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h2 className="text-2xl font-bold text-foreground mb-2">Start Searching</h2>
              <p className="text-muted-foreground">
                Enter a keyword in the search bar to find articles
              </p>
            </Card>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
