import { useState } from 'react';
import { Lock, LogOut, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import ArticleEditor from '@/components/ArticleEditor';
import ArticleCard from '@/components/ArticleCard';
import { useArticles } from '@/contexts/ArticleContext';
import { Article, ArticleFormData, ArticleCategory, CATEGORY_LABELS } from '@/types/article';

/**
 * Admin Dashboard Page
 * Publisher panel for managing articles
 * Features: Authentication, article CRUD, category filtering
 */

export default function Admin() {
  const { articles, addArticle, updateArticle, deleteArticle } = useArticles();

  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem('admin-authenticated') === 'true';
  });

  const [adminPassword, setAdminPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Editor state
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [showEditor, setShowEditor] = useState(false);

  // Filter state
  const [selectedCategory, setSelectedCategory] = useState<ArticleCategory | 'all'>(
    'all'
  );

  // Filtered articles
  const filteredArticles =
    selectedCategory === 'all'
      ? articles
      : articles.filter((a) => a.category === selectedCategory);

  // Authentication handler
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');

    // Simple password check (in production, use proper backend authentication)
    const correctPassword = 'nexus2026';

    if (adminPassword === correctPassword) {
      setIsAuthenticated(true);
      localStorage.setItem('admin-authenticated', 'true');
      setAdminPassword('');
    } else {
      setPasswordError('Incorrect password. Please try again.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('admin-authenticated');
    setEditingArticle(null);
    setShowEditor(false);
  };

  const handlePublish = (formData: ArticleFormData) => {
    if (editingArticle) {
      updateArticle(editingArticle.id, formData);
      setEditingArticle(null);
    } else {
      addArticle(formData);
    }
    setShowEditor(false);
  };

  const handleEdit = (article: Article) => {
    setEditingArticle(article);
    setShowEditor(true);
  };

  const handleCancel = () => {
    setEditingArticle(null);
    setShowEditor(false);
  };

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col">
        <Navigation />

        <div className="flex-1 flex items-center justify-center px-4 py-12">
          <Card className="bg-card/50 backdrop-blur-md border-border w-full max-w-md p-8 space-y-6">
            <div className="text-center space-y-3">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Lock className="w-6 h-6 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">Admin Access</h1>
              </div>
              <p className="text-muted-foreground">
                Enter your password to access the publisher panel
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-foreground">
                  Admin Password
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => {
                    setAdminPassword(e.target.value);
                    setPasswordError('');
                  }}
                  placeholder="Enter password"
                  className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
                  autoFocus
                />
                {passwordError && (
                  <p className="text-xs text-destructive">{passwordError}</p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-3"
              >
                Unlock Admin Panel
              </Button>
            </form>

            <div className="pt-4 border-t border-border text-center">
              <p className="text-xs text-muted-foreground">
                Demo Password: <span className="font-mono text-accent">nexus2026</span>
              </p>
            </div>
          </Card>
        </div>

        <Footer />
      </div>
    );
  }

  // Admin Dashboard
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navigation />

      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 max-w-6xl space-y-12">
          {/* Header with Logout */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-2">
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground">
                Manage articles and publish new content
              </p>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>

          {/* Publisher Panel */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-foreground">Publisher Panel</h2>
              {!showEditor && (
                <Button
                  onClick={() => {
                    setEditingArticle(null);
                    setShowEditor(true);
                  }}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                >
                  + New Article
                </Button>
              )}
            </div>

            {showEditor && (
              <ArticleEditor
                onPublish={handlePublish}
                initialArticle={editingArticle || undefined}
                onCancel={handleCancel}
              />
            )}
          </section>

          {/* Articles Management */}
          <section className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-foreground">
                Published Articles ({filteredArticles.length})
              </h2>
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                  selectedCategory === 'all'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-card/50 text-muted-foreground hover:text-foreground border border-border'
                }`}
              >
                All Articles
              </button>
              {(Object.entries(CATEGORY_LABELS) as [ArticleCategory, string][]).map(
                ([category, label]) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      selectedCategory === category
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card/50 text-muted-foreground hover:text-foreground border border-border'
                    }`}
                  >
                    {label}
                  </button>
                )
              )}
            </div>

            {/* Articles Grid */}
            {filteredArticles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredArticles.map((article) => (
                  <ArticleCard
                    key={article.id}
                    article={article}
                    onEdit={handleEdit}
                    onDelete={deleteArticle}
                    isAdmin={true}
                  />
                ))}
              </div>
            ) : (
              <Card className="bg-card/50 backdrop-blur-md border-border p-12 text-center">
                <p className="text-muted-foreground mb-4">
                  No articles in this category yet.
                </p>
                <Button
                  onClick={() => {
                    setEditingArticle(null);
                    setShowEditor(true);
                  }}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                >
                  Create First Article
                </Button>
              </Card>
            )}
          </section>

          {/* Statistics */}
          <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-card/50 backdrop-blur-md border-border p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                {articles.length}
              </div>
              <p className="text-sm text-muted-foreground">Total Articles</p>
            </Card>
            <Card className="bg-card/50 backdrop-blur-md border-border p-6 text-center">
              <div className="text-3xl font-bold text-accent mb-2">
                {articles.filter((a) => a.featured).length}
              </div>
              <p className="text-sm text-muted-foreground">Featured</p>
            </Card>
            <Card className="bg-card/50 backdrop-blur-md border-border p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">
                {articles.filter((a) => a.videoEmbedUrl).length}
              </div>
              <p className="text-sm text-muted-foreground">With Videos</p>
            </Card>
            <Card className="bg-card/50 backdrop-blur-md border-border p-6 text-center">
              <div className="text-3xl font-bold text-accent mb-2">
                {new Set(articles.map((a) => a.category)).size}
              </div>
              <p className="text-sm text-muted-foreground">Categories</p>
            </Card>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}
