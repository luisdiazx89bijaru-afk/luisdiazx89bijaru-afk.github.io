import Navigation from '@/components/Navigation';
import Hero from '@/components/Hero';
import ContentPillar from '@/components/ContentPillar';
import ArticlesFeed from '@/components/ArticlesFeed';
import SearchOverlay from '@/components/SearchOverlay';
import Newsletter from '@/components/Newsletter';
import Footer from '@/components/Footer';

/**
 * Home Page
 * Digital Futurism with Historical Depth aesthetic
 * - Premium layout with hero section
 * - Four content pillars with video placeholders
 * - Interactive community engagement
 * - Dynamic articles feed from admin dashboard
 * - Newsletter subscription
 */

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Search Overlay */}
      <SearchOverlay />

      {/* Navigation */}
      <Navigation />

      {/* Hero Section */}
      <Hero />

      {/* Main Content Area */}
      <div id="content" className="relative z-10">
        {/* Content Pillar 1: International News */}
        <ContentPillar
          id="international-news"
          title="International News & Geopolitics"
          subtitle="Global Affairs"
          backgroundImage="https://d2xsxph8kpxj0f.cloudfront.net/310519663634538465/NryUvDT3m4fXKnaUiJwk7z/section-international-news-EfawYQ9d6TrP9sntbGUagM.webp"
          accentColor="cyan"
          content={{
            introduction:
              "In an increasingly interconnected world, understanding geopolitical dynamics is essential. From Middle Eastern conflicts to Asian power shifts, we analyze the forces shaping international relations and their implications for global stability.",
            mainText:
              "The contemporary geopolitical landscape reflects centuries of historical tensions, cultural exchanges, and power dynamics. Today's conflicts are not isolated events but manifestations of deeper historical narratives. Our analysis examines current events through the lens of historical precedent, exploring how past decisions continue to influence present-day international relations. We investigate the role of superpowers, emerging economies, and regional actors in shaping global affairs. Through rigorous investigation and expert commentary, we provide context that mainstream media often overlooks, helping readers understand not just what is happening, but why it matters for the future of global civilization.",
            keyTakeaway:
              "Geopolitics is history in motion. Understanding today's international conflicts requires knowledge of historical context, cultural nuances, and the long-term strategic interests of nations.",
          }}
          videoPlaceholder={{
            title: "Geopolitical Analysis Video",
            description: "Embed your explanatory video about current international affairs",
          }}
        />

        {/* Published Articles Feed */}
        <section className="relative w-full py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
          <div className="relative z-10 container mx-auto px-4 max-w-4xl">
            <div className="mb-12 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-primary to-transparent" />
                <span className="text-sm font-mono text-primary uppercase tracking-widest">
                  Latest Articles
                </span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
                International News Articles
              </h3>
            </div>
            <ArticlesFeed category="international-news" />
          </div>
        </section>

        {/* Content Pillar 2: Religions & Philosophy */}
        <ContentPillar
          id="religions"
          title="Religions & Traditional Perspectives"
          subtitle="Spiritual Wisdom"
          backgroundImage="https://d2xsxph8kpxj0f.cloudfront.net/310519663634538465/NryUvDT3m4fXKnaUiJwk7z/section-religions-protestant-church-Fhn8zRNgEEcDxspxiUK7DS.webp"
          accentColor="gold"
          content={{
            introduction:
              "Religious and philosophical traditions have shaped human civilization for millennia. From the Council of Nicaea to contemporary interfaith dialogue, we explore how spiritual perspectives inform our understanding of ethics, meaning, and social organization.",
            mainText:
              "Religion is not merely a matter of personal faith—it is a fundamental force in human history, politics, and culture. The major world religions—Christianity, Islam, Judaism, Buddhism, Hinduism, and others—have profoundly influenced the development of civilizations, legal systems, and moral frameworks. We examine sacred texts, theological developments, and religious movements with scholarly rigor and respectful engagement. Our coverage includes historical turning points like the Council of Nicaea, which shaped Christian doctrine, as well as contemporary religious movements and their social impact. We also explore the philosophical underpinnings of different traditions and how they address universal human questions about meaning, purpose, and ethics. By understanding religious perspectives, we gain deeper insight into the motivations and worldviews of billions of people.",
            keyTakeaway:
              "Religious and philosophical traditions are not relics of the past—they remain vital forces shaping human values, social structures, and responses to contemporary challenges.",
          }}
          videoPlaceholder={{
            title: "Religious History Documentary",
            description: "Embed video exploring major religious traditions and their historical impact",
          }}
        />

        {/* Published Articles Feed */}
        <section className="relative w-full py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
          <div className="relative z-10 container mx-auto px-4 max-w-4xl">
            <div className="mb-12 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-accent to-transparent" />
                <span className="text-sm font-mono text-accent uppercase tracking-widest">
                  Latest Articles
                </span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
                Religion & Philosophy Articles
              </h3>
            </div>
            <ArticlesFeed category="religions" />
          </div>
        </section>

        {/* Content Pillar 3: Politics & Finance */}
        <ContentPillar
          id="politics-finance"
          title="Global Politics & Finance/Money Systems"
          subtitle="Economic Power"
          backgroundImage="https://d2xsxph8kpxj0f.cloudfront.net/310519663634538465/NryUvDT3m4fXKnaUiJwk7z/section-politics-finance-UBuNXwfvg3Duni3MuQTxD5.webp"
          accentColor="crimson"
          content={{
            introduction:
              "Money is power. Understanding global financial systems, economic policy, and the intersection of politics and economics is crucial for comprehending modern geopolitics and social inequality.",
            mainText:
              "The global financial system is a complex web of institutions, policies, and power dynamics that shape the lives of billions. From central banks to cryptocurrency, from trade agreements to debt crises, economic decisions have profound political and social consequences. We analyze the history of money systems—from the gold standard to fiat currency to digital assets—and examine how financial policy shapes inequality, opportunity, and political stability. Our coverage includes investigations into corporate influence on politics, the role of financial institutions in geopolitical conflicts, and emerging economic models. We also explore the philosophical questions underlying capitalism, socialism, and alternative economic systems. By understanding the intersection of politics and finance, readers can better comprehend the forces driving global events and social change.",
            keyTakeaway:
              "Economic systems are not neutral—they reflect political choices and power structures. Understanding finance is essential to understanding politics and social justice.",
          }}
          videoPlaceholder={{
            title: "Financial Systems Explained",
            description: "Embed video breaking down global economics and financial policy",
          }}
        />

        {/* Published Articles Feed */}
        <section className="relative w-full py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
          <div className="relative z-10 container mx-auto px-4 max-w-4xl">
            <div className="mb-12 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-secondary to-transparent" />
                <span className="text-sm font-mono text-secondary uppercase tracking-widest">
                  Latest Articles
                </span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
                Politics & Finance Articles
              </h3>
            </div>
            <ArticlesFeed category="politics-finance" />
          </div>
        </section>

        {/* Content Pillar 4: AI Revolution */}
        <ContentPillar
          id="ai-revolution"
          title="The Daily AI Revolution & Tech Automation"
          subtitle="Future Technology"
          backgroundImage="https://d2xsxph8kpxj0f.cloudfront.net/310519663634538465/NryUvDT3m4fXKnaUiJwk7z/section-ai-revolution-TZdQj3fTebVYuYvk6fXJ5W.webp"
          accentColor="cyan"
          content={{
            introduction:
              "Artificial intelligence and automation are reshaping society at an unprecedented pace. From labor markets to creative industries to governance, we examine the implications of the AI revolution for human civilization.",
            mainText:
              "Artificial intelligence is not a distant future technology—it is already transforming every sector of society. Machine learning algorithms influence what we see on social media, autonomous systems are entering transportation and manufacturing, and AI-generated content is raising new questions about creativity and authenticity. We cover the latest developments in AI technology, analyze the economic implications of automation, and explore the ethical and philosophical questions these technologies raise. What does it mean to be human in an age of artificial intelligence? How should society manage the transition as automation displaces workers? What safeguards are necessary to ensure AI benefits all of humanity rather than concentrating power? These are not merely technical questions—they are fundamentally questions about human values and the kind of future we want to build. Our coverage bridges technical analysis with humanistic inquiry, helping readers understand both the capabilities and limitations of AI, as well as its profound implications for work, creativity, and human meaning.",
            keyTakeaway:
              "The AI revolution is not inevitable—it is a choice. How we develop and deploy AI technology will determine whether it serves human flourishing or concentrates power and exacerbates inequality.",
          }}
          videoPlaceholder={{
            title: "AI Technology Breakdown",
            description: "Embed video exploring artificial intelligence, automation, and future implications",
          }}
        />

        {/* Published Articles Feed */}
        <section className="relative w-full py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
          <div className="relative z-10 container mx-auto px-4 max-w-4xl">
            <div className="mb-12 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-primary to-transparent" />
                <span className="text-sm font-mono text-primary uppercase tracking-widest">
                  Latest Articles
                </span>
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
                AI Revolution & Tech Articles
              </h3>
            </div>
            <ArticlesFeed category="ai-revolution" />
          </div>
        </section>
      </div>

      {/* Newsletter Section */}
      <Newsletter />

      {/* Footer */}
      <Footer />
    </div>
  );
}
