import { Link } from 'wouter';
import { Mail, Globe, Github } from 'lucide-react';

/**
 * Footer Component
 * Digital Futurism with Historical Depth aesthetic
 * - Glassmorphism design
 * - Multiple column layout
 * - Contact and collaboration information
 */

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative w-full border-t border-border bg-background/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-foreground font-bold text-sm">WN</span>
              </div>
              <span className="text-lg font-bold text-foreground">
                WORLD <span className="text-primary">NEXUS</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Bridging contemporary global issues with deep historical and philosophical understanding.
            </p>
          </div>

          {/* Content Pillars */}
          <div className="space-y-4">
            <h3 className="font-bold text-foreground">Content</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/international-news">
                  <a className="text-muted-foreground hover:text-primary transition-colors duration-200">
                    International News
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/religions">
                  <a className="text-muted-foreground hover:text-primary transition-colors duration-200">
                    Religions & Philosophy
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/politics-finance">
                  <a className="text-muted-foreground hover:text-primary transition-colors duration-200">
                    Politics & Finance
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/ai-revolution">
                  <a className="text-muted-foreground hover:text-primary transition-colors duration-200">
                    AI Revolution
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <h3 className="font-bold text-foreground">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Admin & Connect */}
          <div className="space-y-4">
            <h3 className="font-bold text-foreground">Admin & Connect</h3>
            <div className="space-y-2 mb-4">
              <a
                href="/admin"
                className="block text-sm text-muted-foreground hover:text-primary transition-colors duration-200"
              >
                📊 Admin Dashboard
              </a>
            </div>
            <div className="flex gap-3">
              <a
                href="mailto:contact@worldnexushistory.com"
                className="p-2 bg-card/50 hover:bg-card border border-border rounded-lg text-muted-foreground hover:text-primary transition-all duration-200"
                title="Email"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a
                href="https://worldnexushistory.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-card/50 hover:bg-card border border-border rounded-lg text-muted-foreground hover:text-primary transition-all duration-200"
                title="Website"
              >
                <Globe className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="p-2 bg-card/50 hover:bg-card border border-border rounded-lg text-muted-foreground hover:text-primary transition-all duration-200"
                title="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent mb-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>
            © {currentYear} WORLD NEXUS. All rights reserved.
          </p>
          <p>
            Crafted with <span className="text-primary">◆</span> for intellectual discourse
          </p>
        </div>

        {/* Collaboration Notice */}
        <div className="mt-8 p-4 bg-card/30 backdrop-blur-sm border border-border rounded-lg text-center text-xs text-muted-foreground">
          <p>
            For media partnerships, collaborations, and inquiries: <br />
            <a
              href="mailto:contact@worldnexushistory.com"
              className="text-primary hover:text-primary/80 font-semibold transition-colors duration-200"
            >
              contact@worldnexushistory.com
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
