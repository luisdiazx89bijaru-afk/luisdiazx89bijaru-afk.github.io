import { useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useSearch } from '@/contexts/SearchContext';

/**
 * SearchBar Component
 * Toggleable search input in navigation header
 * Implements live keyword filtering with instant results
 */

export default function SearchBar() {
  const { searchQuery, setSearchQuery, isSearchOpen, setIsSearchOpen, totalResults, clearSearch } =
    useSearch();
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when search opens
  useEffect(() => {
    if (isSearchOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isSearchOpen]);

  // Close search on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  const handleToggle = () => {
    setIsSearchOpen(!isSearchOpen);
    if (isSearchOpen) {
      clearSearch();
    }
  };

  return (
    <div className="relative">
      {/* Search Icon Button */}
      <button
        onClick={handleToggle}
        className="p-2 hover:bg-card/50 rounded-lg transition-all duration-200 text-muted-foreground hover:text-primary"
        title="Search articles (Cmd+K)"
        aria-label="Toggle search"
      >
        <Search className="w-5 h-5" />
      </button>

      {/* Search Input Overlay */}
      {isSearchOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40"
            onClick={() => setIsSearchOpen(false)}
          />

          {/* Search Panel */}
          <div className="absolute top-full right-0 mt-2 w-96 max-w-[calc(100vw-2rem)] bg-card/95 backdrop-blur-md border border-border rounded-lg shadow-2xl z-50 overflow-hidden">
            {/* Search Input */}
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <Search className="w-5 h-5 text-primary flex-shrink-0" />
                <input
                  ref={inputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search articles by keyword..."
                  className="flex-1 bg-transparent text-foreground placeholder-muted-foreground focus:outline-none text-sm"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="p-1 hover:bg-background rounded transition-colors duration-200"
                    title="Clear search"
                  >
                    <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                  </button>
                )}
              </div>
            </div>

            {/* Results Summary */}
            {searchQuery && (
              <div className="px-4 py-2 bg-background/50 text-xs text-muted-foreground border-b border-border">
                {totalResults > 0 ? (
                  <span>
                    Found <span className="text-primary font-semibold">{totalResults}</span> result
                    {totalResults !== 1 ? 's' : ''}
                  </span>
                ) : (
                  <span>No articles match your search</span>
                )}
              </div>
            )}

            {/* Quick Tips */}
            {!searchQuery && (
              <div className="p-4 text-xs text-muted-foreground space-y-2">
                <p className="font-semibold text-foreground">Search Tips:</p>
                <ul className="space-y-1 list-disc list-inside">
                  <li>Search by article title</li>
                  <li>Search by author name</li>
                  <li>Search by keywords in content</li>
                  <li>Press <kbd className="px-1.5 py-0.5 bg-background rounded text-xs border border-border">Esc</kbd> to close</li>
                </ul>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
