import { useLocation } from 'wouter';
import { Search, X } from 'lucide-react';
import { useSearch } from '@/contexts/SearchContext';
import ArticleCard from './ArticleCard';

/**
 * SearchOverlay Component
 * Displays search results inline on the home page
 * Shows when search is active with live filtering
 */

export default function SearchOverlay() {
  const [, navigate] = useLocation();
  const { searchQuery, setSearchQuery, searchResults, totalResults, isSearchOpen, setIsSearchOpen } =
    useSearch();

  if (!isSearchOpen || !searchQuery) {
    return null;
  }

  const handleViewAll = () => {
    navigate('/search');
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-start justify-center pt-20">
      <div className="w-full max-w-4xl mx-4 bg-card/95 backdrop-blur-md border border-border rounded-lg shadow-2xl max-h-[80vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-card/95 border-b border-border p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Search className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-bold text-foreground">
              Search Results
              {totalResults > 0 && (
                <span className="text-primary ml-2">({totalResults})</span>
              )}
            </h2>
          </div>
          <button
            onClick={() => setIsSearchOpen(false)}
            className="p-2 hover:bg-background rounded-lg transition-colors duration-200"
          >
            <X className="w-5 h-5 text-muted-foreground hover:text-foreground" />
          </button>
        </div>

        {/* Results */}
        <div className="p-6">
          {totalResults > 0 ? (
            <div className="space-y-4">
              {searchResults.slice(0, 5).map((article) => (
                <div
                  key={article.id}
                  className="p-4 bg-background/50 border border-border rounded-lg hover:border-primary/50 transition-colors duration-200 cursor-pointer"
                  onClick={() => {
                    setIsSearchOpen(false);
                    handleViewAll();
                  }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-foreground hover:text-primary transition-colors duration-200 line-clamp-2">
                        {article.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {article.excerpt || article.content.substring(0, 100)}...
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                        <span>{article.author}</span>
                        <span>•</span>
                        <span className="text-primary font-semibold">
                          {article.matchType === 'title'
                            ? 'Title Match'
                            : article.matchType === 'excerpt'
                              ? 'Summary Match'
                              : 'Content Match'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {totalResults > 5 && (
                <button
                  onClick={handleViewAll}
                  className="w-full mt-4 px-4 py-3 bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-lg transition-colors duration-200"
                >
                  View All {totalResults} Results
                </button>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-bold text-foreground mb-2">No Results Found</h3>
              <p className="text-muted-foreground">
                No articles match "<span className="font-semibold">{searchQuery}</span>"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
