import { useState } from 'react';
import { Link } from 'wouter';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SearchBar from './SearchBar';

/**
 * Navigation Component
 * Digital Futurism with Historical Depth aesthetic
 * - Neon cyan accents (#00d9ff) for tech elements
 * - Deep indigo background (#0f1a2e)
 * - Crimson and gold for historical/philosophical content
 * - Glassmorphism effects with backdrop blur
 * - Smooth transitions and hover effects
 */

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: 'Home', href: '/' },
    { label: 'International News', href: '/international-news' },
    { label: 'Religions', href: '/religions' },
    { label: 'Politics & Finance', href: '/politics-finance' },
    { label: 'AI Revolution', href: '/ai-revolution' },
  ];

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-2 group">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center transform group-hover:scale-110 transition-transform duration-200">
                <span className="text-foreground font-bold text-sm">WN</span>
              </div>
              <span className="text-lg font-bold text-foreground hidden sm:inline">
                WORLD <span className="text-primary">NEXUS</span>
              </span>
            </a>
          </Link>

          {/* Search Bar */}
          <SearchBar />

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item, index) => (
              <div key={item.href} className="flex items-center">
                <Link href={item.href}>
                  <a className="px-4 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors duration-200 relative group">
                    {item.label}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-accent group-hover:w-full transition-all duration-300" />
                  </a>
                </Link>
                {index < navItems.length - 1 && (
                  <div className="w-px h-4 bg-border mx-2" />
                )}
              </div>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 hover:bg-card rounded-lg transition-colors duration-200"
          >
            {isOpen ? (
              <X className="w-5 h-5 text-primary" />
            ) : (
              <Menu className="w-5 h-5 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2 animate-in fade-in slide-in-from-top-2 duration-200">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className="block px-4 py-2 text-sm font-medium text-foreground hover:text-primary hover:bg-card rounded-lg transition-colors duration-200"
                  onClick={() => setIsOpen(false)}
                >
                  {item.label}
                </a>
              </Link>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
