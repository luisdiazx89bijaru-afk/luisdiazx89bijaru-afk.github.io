import { useState, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Hero Component
 * Digital Futurism with Historical Depth aesthetic
 * - Rotating philosophical quotes with fade transitions
 * - High-quality background image with overlay
 * - Glitch effect on text elements
 * - Interactive CTA buttons
 */

const PHILOSOPHICAL_QUOTES = [
  {
    text: "The future is not something we enter. The future is something we create.",
    author: "Leonard I. Sweet",
    theme: "innovation"
  },
  {
    text: "History is a set of lies agreed upon.",
    author: "Napoleon Bonaparte",
    theme: "history"
  },
  {
    text: "Technology is best when it brings people together.",
    author: "Matt Mullenweg",
    theme: "technology"
  },
  {
    text: "The only constant in life is change.",
    author: "Heraclitus",
    theme: "philosophy"
  },
  {
    text: "In the middle of difficulty lies opportunity.",
    author: "Albert Einstein",
    theme: "wisdom"
  }
];

export default function Hero() {
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsTransitioning(true);
      setTimeout(() => {
        setCurrentQuoteIndex((prev) => (prev + 1) % PHILOSOPHICAL_QUOTES.length);
        setIsTransitioning(false);
      }, 300);
    }, 6000);

    return () => clearInterval(interval);
  }, []);

  const currentQuote = PHILOSOPHICAL_QUOTES[currentQuoteIndex];

  return (
    <section className="relative w-full h-screen min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663634538465/NryUvDT3m4fXKnaUiJwk7z/hero-nexus-main-UKBnRwgSMTtLgm8LzUiJ83.webp)',
        }}
      >
        {/* Multiple Overlay Layers for Depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/60 to-background/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/50 to-transparent" />
        
        {/* Animated Glitch Effect */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent animate-pulse" />
        </div>
      </div>

      {/* Content Container */}
      <div className="relative z-10 container mx-auto px-4 max-w-4xl">
        <div className="space-y-8">
          {/* Animated Quote Section */}
          <div className="space-y-6">
            {/* Quote Label */}
            <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-gradient-to-b from-primary to-accent" />
              <span className="text-sm font-mono text-primary uppercase tracking-widest">
                Philosophical Insight
              </span>
            </div>

            {/* Quote Text with Fade Transition */}
            <div className="min-h-32 flex flex-col justify-center">
              <blockquote
                className={`text-4xl md:text-5xl font-bold text-foreground leading-tight transition-all duration-300 ${
                  isTransitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
                }`}
              >
                "{currentQuote.text}"
              </blockquote>
            </div>

            {/* Author Attribution */}
            <div
              className={`flex items-center gap-2 transition-all duration-300 ${
                isTransitioning ? 'opacity-0' : 'opacity-100'
              }`}
            >
              <div className="w-12 h-px bg-gradient-to-r from-accent to-transparent" />
              <span className="text-lg text-accent font-mono">
                — {currentQuote.author}
              </span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-8">
            <Button
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-8 py-6 text-lg group"
              onClick={() => document.getElementById('content')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Explore Content
              <ChevronRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="border-accent text-accent hover:bg-accent/10 font-bold px-8 py-6 text-lg"
            >
              Subscribe to Newsletter
            </Button>
          </div>

          {/* Quote Indicator Dots */}
          <div className="flex gap-2 pt-8">
            {PHILOSOPHICAL_QUOTES.map((_, index) => (
              <button
                key={index}
                onClick={() => {
                  setIsTransitioning(true);
                  setTimeout(() => {
                    setCurrentQuoteIndex(index);
                    setIsTransitioning(false);
                  }, 300);
                }}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  index === currentQuoteIndex
                    ? 'bg-primary w-8'
                    : 'bg-muted-foreground hover:bg-foreground/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs text-muted-foreground uppercase tracking-widest">Scroll</span>
          <div className="w-px h-6 bg-gradient-to-b from-primary to-transparent" />
        </div>
      </div>
    </section>
  );
}
