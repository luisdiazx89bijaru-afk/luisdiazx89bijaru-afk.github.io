import { useState } from 'react';
import { Send, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Article, ArticleFormData, ArticleCategory, CATEGORY_LABELS } from '@/types/article';

/**
 * ArticleEditor Component
 * Clean publisher panel for creating and editing articles
 * Features: Title input, category selection, content textarea, video embed
 */

interface ArticleEditorProps {
  onPublish: (formData: ArticleFormData) => void;
  initialArticle?: Article;
  onCancel?: () => void;
  isLoading?: boolean;
}

export default function ArticleEditor({
  onPublish,
  initialArticle,
  onCancel,
  isLoading = false,
}: ArticleEditorProps) {
  const [formData, setFormData] = useState<ArticleFormData>({
    title: initialArticle?.title || '',
    category: initialArticle?.category || 'international-news',
    content: initialArticle?.content || '',
    videoEmbedUrl: initialArticle?.videoEmbedUrl || '',
    author: initialArticle?.author || 'WORLD NEXUS Editorial',
  });

  const [errors, setErrors] = useState<Partial<Record<keyof ArticleFormData, string>>>({});

  const validateForm = (): boolean => {
    const newErrors: typeof errors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Article title is required';
    }

    if (!formData.content.trim()) {
      newErrors.content = 'Article content is required';
    } else if (formData.content.trim().length < 100) {
      newErrors.content = 'Article content must be at least 100 characters';
    }

    if (!formData.author.trim()) {
      newErrors.author = 'Author name is required';
    }

    if (formData.videoEmbedUrl && !isValidUrl(formData.videoEmbedUrl)) {
      newErrors.videoEmbedUrl = 'Please enter a valid URL';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (validateForm()) {
      onPublish(formData);
      if (!initialArticle) {
        // Reset form only if creating new article
        setFormData({
          title: '',
          category: 'international-news',
          content: '',
          videoEmbedUrl: '',
          author: 'WORLD NEXUS Editorial',
        });
      }
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur-md border-border p-6 md:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl md:text-3xl font-bold text-foreground">
          {initialArticle ? 'Edit Article' : 'Publish New Article'}
        </h2>
        {onCancel && (
          <button
            onClick={onCancel}
            className="p-2 hover:bg-card rounded-lg transition-colors duration-200"
          >
            <X className="w-5 h-5 text-muted-foreground hover:text-foreground" />
          </button>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Title Input */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Article Title *
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="Enter article title"
            className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
          />
          {errors.title && (
            <p className="text-xs text-destructive">{errors.title}</p>
          )}
        </div>

        {/* Category Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-foreground">
              Category *
            </label>
            <select
              value={formData.category}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  category: e.target.value as ArticleCategory,
                })
              }
              className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
            >
              {(Object.entries(CATEGORY_LABELS) as [ArticleCategory, string][]).map(
                ([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                )
              )}
            </select>
          </div>

          {/* Author Input */}
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-foreground">
              Author *
            </label>
            <input
              type="text"
              value={formData.author}
              onChange={(e) => setFormData({ ...formData, author: e.target.value })}
              placeholder="Author name"
              className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
            />
            {errors.author && (
              <p className="text-xs text-destructive">{errors.author}</p>
            )}
          </div>
        </div>

        {/* Video Embed URL */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Video Embed Link (Optional)
          </label>
          <input
            type="url"
            value={formData.videoEmbedUrl || ''}
            onChange={(e) =>
              setFormData({ ...formData, videoEmbedUrl: e.target.value })
            }
            placeholder="https://youtube.com/embed/... or https://vimeo.com/..."
            className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
          />
          {errors.videoEmbedUrl && (
            <p className="text-xs text-destructive">{errors.videoEmbedUrl}</p>
          )}
          <p className="text-xs text-muted-foreground">
            Paste the full embed URL from YouTube or Vimeo
          </p>
        </div>

        {/* Content Textarea */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Article Content * (minimum 100 characters)
          </label>
          <textarea
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            placeholder="Write your article content here. Include key insights, analysis, and takeaways..."
            rows={12}
            className="w-full bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200 resize-none"
          />
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              {formData.content.length} characters
            </p>
            {errors.content && (
              <p className="text-xs text-destructive">{errors.content}</p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button
            type="submit"
            disabled={isLoading}
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-6 py-3 gap-2 flex-1"
          >
            <Send className="w-4 h-4" />
            {isLoading
              ? 'Publishing...'
              : initialArticle
                ? 'Update Article'
                : 'Publish Article'}
          </Button>
          {onCancel && (
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="px-6 py-3"
            >
              Cancel
            </Button>
          )}
        </div>
      </form>

      {/* Character Count Info */}
      <div className="pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground text-center">
          ✓ All fields marked with * are required. Your article will be published
          immediately upon submission.
        </p>
      </div>
    </Card>
  );
}
