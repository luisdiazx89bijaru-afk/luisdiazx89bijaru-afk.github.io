import { Edit2, Trash2, Calendar, User, Tag } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Article, CATEGORY_LABELS, CATEGORY_COLORS } from '@/types/article';

/**
 * ArticleCard Component
 * Displays article preview with management controls (Edit/Delete)
 * Shows metadata: date, author, category
 */

interface ArticleCardProps {
  article: Article;
  onEdit?: (article: Article) => void;
  onDelete?: (id: string) => void;
  isAdmin?: boolean;
}

const accentColorMap = {
  cyan: '#00d9ff',
  crimson: '#8b1a1a',
  gold: '#d4af37',
};

export default function ArticleCard({
  article,
  onEdit,
  onDelete,
  isAdmin = false,
}: ArticleCardProps) {
  const categoryColor = CATEGORY_COLORS[article.category];
  const accentColor = accentColorMap[categoryColor];

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Card className="bg-card/50 backdrop-blur-md border-border overflow-hidden hover:border-primary/50 transition-colors duration-300 group">
      {/* Header with Category Badge */}
      <div className="p-6 space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-3">
              <div
                className="px-3 py-1 rounded-full text-xs font-semibold"
                style={{
                  backgroundColor: `${accentColor}20`,
                  color: accentColor,
                  border: `1px solid ${accentColor}40`,
                }}
              >
                {CATEGORY_LABELS[article.category]}
              </div>
              {article.featured && (
                <div className="px-3 py-1 rounded-full text-xs font-semibold bg-accent/20 text-accent border border-accent/40">
                  Featured
                </div>
              )}
            </div>

            <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-200 line-clamp-2">
              {article.title}
            </h3>
          </div>

          {/* Admin Controls */}
          {isAdmin && (onEdit || onDelete) && (
            <div className="flex gap-2 flex-shrink-0">
              {onEdit && (
                <button
                  onClick={() => onEdit(article)}
                  className="p-2 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg transition-colors duration-200"
                  title="Edit article"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={() => {
                    if (
                      confirm(
                        'Are you sure you want to delete this article? This action cannot be undone.'
                      )
                    ) {
                      onDelete(article.id);
                    }
                  }}
                  className="p-2 bg-destructive/10 hover:bg-destructive/20 text-destructive rounded-lg transition-colors duration-200"
                  title="Delete article"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Excerpt */}
        <p className="text-foreground/70 line-clamp-3">
          {article.excerpt || article.content.substring(0, 150) + '...'}
        </p>

        {/* Metadata */}
        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground pt-4 border-t border-border">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" />
            <span>{formatDate(article.createdAt)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <User className="w-3.5 h-3.5" />
            <span>{article.author}</span>
          </div>
          {article.videoEmbedUrl && (
            <div className="flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5" />
              <span>Video included</span>
            </div>
          )}
        </div>
      </div>

      {/* Video Preview (if available) */}
      {article.videoEmbedUrl && (
        <div className="px-6 pb-6">
          <div className="relative w-full aspect-video bg-background/50 rounded-lg overflow-hidden border border-border">
            <iframe
              src={article.videoEmbedUrl}
              title={article.title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
        </div>
      )}
    </Card>
  );
}
