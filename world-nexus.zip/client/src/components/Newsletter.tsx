import { useState } from 'react';
import { Mail, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

/**
 * Newsletter Component
 * Digital Futurism with Historical Depth aesthetic
 * - Glassmorphism card design
 * - Email subscription form
 * - Success state animation
 */

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setEmail('');
      setIsLoading(false);
      
      // Reset after 3 seconds
      setTimeout(() => setIsSubscribed(false), 3000);
    }, 1000);
  };

  return (
    <section className="relative w-full py-20 overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 max-w-2xl">
        <Card className="bg-card/50 backdrop-blur-md border-border overflow-hidden">
          <div className="p-8 md:p-12 space-y-6">
            {/* Header */}
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Mail className="w-6 h-6 text-primary" />
                <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                  Stay Connected
                </h2>
              </div>
              <p className="text-lg text-foreground/70">
                Get the latest insights on global affairs, technology, and philosophy delivered to your inbox.
              </p>
            </div>

            {/* Subscription Form */}
            {!isSubscribed ? (
              <form onSubmit={handleSubscribe} className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    placeholder="Enter your email address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="flex-1 bg-background/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors duration-200"
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !email.trim()}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-6 py-3 whitespace-nowrap"
                  >
                    {isLoading ? 'Subscribing...' : 'Subscribe'}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  We respect your privacy. Unsubscribe at any time.
                </p>
              </form>
            ) : (
              <div className="flex items-center gap-3 p-4 bg-primary/10 border border-primary/20 rounded-lg animate-in fade-in slide-in-from-bottom-2 duration-300">
                <CheckCircle className="w-6 h-6 text-primary flex-shrink-0" />
                <div>
                  <p className="font-semibold text-foreground">Welcome to WORLD NEXUS!</p>
                  <p className="text-sm text-foreground/70">
                    Check your email for confirmation and exclusive insights.
                  </p>
                </div>
              </div>
            )}

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 pt-4">
              <div className="text-center space-y-2">
                <div className="text-2xl font-bold text-primary">4</div>
                <p className="text-xs text-muted-foreground">Content Pillars</p>
              </div>
              <div className="text-center space-y-2">
                <div className="text-2xl font-bold text-accent">∞</div>
                <p className="text-xs text-muted-foreground">Insights</p>
              </div>
              <div className="text-center space-y-2">
                <div className="text-2xl font-bold text-primary">Weekly</div>
                <p className="text-xs text-muted-foreground">Updates</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Collaboration Info */}
        <div className="mt-12 p-6 bg-card/30 backdrop-blur-sm border border-border rounded-lg text-center space-y-3">
          <p className="text-sm text-muted-foreground">
            For collaborations and partnerships, contact us at:
          </p>
          <a
            href="mailto:contact@worldnexushistory.com"
            className="inline-block text-primary hover:text-primary/80 font-semibold transition-colors duration-200"
          >
            worldnexushistory.com
          </a>
        </div>
      </div>
    </section>
  );
}
