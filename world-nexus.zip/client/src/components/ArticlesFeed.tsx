import { useArticles } from '@/contexts/ArticleContext';
import { ArticleCategory } from '@/types/article';
import ArticleCard from './ArticleCard';

/**
 * ArticlesFeed Component
 * Displays published articles for a specific category
 * Integrates with ArticleContext to show dynamically updated content
 */

interface ArticlesFeedProps {
  category: ArticleCategory;
  limit?: number;
}

export default function ArticlesFeed({ category, limit }: ArticlesFeedProps) {
  const { getArticlesByCategory } = useArticles();
  const articles = getArticlesByCategory(category);
  const displayArticles = limit ? articles.slice(0, limit) : articles;

  return (
    <div className="space-y-6">
      {displayArticles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {displayArticles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <p>No articles published in this category yet.</p>
        </div>
      )}
    </div>
  );
}
