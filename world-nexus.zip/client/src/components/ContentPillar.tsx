import { useState } from 'react';
import { Play, BookOpen, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

/**
 * ContentPillar Component
 * Digital Futurism with Historical Depth aesthetic
 * - Glassmorphism card design with backdrop blur
 * - Video placeholder with play button
 * - Web-book reading layout with blockquotes
 * - Interactive engagement elements
 */

interface ContentPillarProps {
  id: string;
  title: string;
  subtitle: string;
  backgroundImage: string;
  accentColor: 'cyan' | 'crimson' | 'gold';
  content: {
    introduction: string;
    mainText: string;
    keyTakeaway: string;
  };
  videoPlaceholder?: {
    title: string;
    description: string;
  };
}

const accentColorMap = {
  cyan: '#00d9ff',
  crimson: '#8b1a1a',
  gold: '#d4af37',
};

export default function ContentPillar({
  id,
  title,
  subtitle,
  backgroundImage,
  accentColor,
  content,
  videoPlaceholder,
}: ContentPillarProps) {
  const [showComments, setShowComments] = useState(false);
  const [comment, setComment] = useState('');

  return (
    <section
      id={id}
      className="relative w-full py-20 overflow-hidden"
    >
      {/* Background with Diagonal Accent */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${backgroundImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background" />
      </div>

      {/* Diagonal Accent Bar */}
      <div
        className="absolute top-0 right-0 w-1 h-32 opacity-50"
        style={{
          background: `linear-gradient(180deg, ${accentColorMap[accentColor]} 0%, transparent 100%)`,
        }}
      />

      {/* Content Container */}
      <div className="relative z-10 container mx-auto px-4 max-w-4xl">
        {/* Section Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-3">
            <div
              className="w-1 h-8"
              style={{
                background: `linear-gradient(180deg, ${accentColorMap[accentColor]} 0%, transparent 100%)`,
              }}
            />
            <span
              className="text-sm font-mono uppercase tracking-widest"
              style={{ color: accentColorMap[accentColor] }}
            >
              {subtitle}
            </span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
            {title}
          </h2>
        </div>

        {/* Two-Column Layout: Content + Video */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Main Content - 2 columns */}
          <div className="lg:col-span-2 space-y-8">
            {/* Introduction */}
            <p className="text-lg text-foreground/90 leading-relaxed">
              {content.introduction}
            </p>

            {/* Main Reading Content */}
            <div className="space-y-6">
              <p className="text-foreground/85 leading-relaxed text-justify">
                {content.mainText}
              </p>

              {/* Key Takeaway Blockquote */}
              <div
                className="pl-6 py-6 border-l-4 bg-card/50 backdrop-blur-sm rounded-lg"
                style={{
                  borderColor: accentColorMap[accentColor],
                }}
              >
                <p className="text-lg font-semibold text-foreground italic">
                  {content.keyTakeaway}
                </p>
              </div>
            </div>

            {/* Read More Button */}
            <Button
              className="gap-2"
              style={{
                backgroundColor: accentColorMap[accentColor],
                color: '#0f1a2e',
              }}
            >
              <BookOpen className="w-4 h-4" />
              Read Full Article
            </Button>
          </div>

          {/* Video Placeholder - 1 column */}
          {videoPlaceholder && (
            <div className="lg:col-span-1">
              <Card className="bg-card/50 backdrop-blur-md border-border overflow-hidden group cursor-pointer hover:border-primary/50 transition-colors duration-300">
                <div
                  className="relative w-full aspect-video bg-gradient-to-br from-muted to-background flex items-center justify-center overflow-hidden"
                  style={{
                    background: `linear-gradient(135deg, rgba(0, 217, 255, 0.1) 0%, rgba(139, 26, 26, 0.1) 100%)`,
                  }}
                >
                  {/* Animated Background Pattern */}
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent group-hover:animate-pulse" />
                  </div>

                  {/* Play Button */}
                  <div className="relative z-10 flex flex-col items-center gap-4">
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                      style={{
                        backgroundColor: accentColorMap[accentColor],
                      }}
                    >
                      <Play
                        className="w-8 h-8 ml-1"
                        style={{ color: '#0f1a2e' }}
                        fill={accentColorMap[accentColor]}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground text-center px-4">
                      Click to embed video
                    </span>
                  </div>
                </div>

                {/* Video Info */}
                <div className="p-4 space-y-2">
                  <h4 className="font-semibold text-foreground text-sm">
                    {videoPlaceholder.title}
                  </h4>
                  <p className="text-xs text-muted-foreground">
                    {videoPlaceholder.description}
                  </p>
                </div>
              </Card>
            </div>
          )}
        </div>

        {/* Community Engagement Section */}
        <div className="mt-16 pt-12 border-t border-border">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <MessageCircle className="w-5 h-5" style={{ color: accentColorMap[accentColor] }} />
              <h3 className="text-2xl font-bold text-foreground">Community Thoughts</h3>
            </div>

            {/* Comment Form */}
            <Card className="bg-card/50 backdrop-blur-md border-border p-6 space-y-4">
              <textarea
                placeholder="Share your perspective on this topic..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                className="w-full bg-background/50 border border-border rounded-lg p-4 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary resize-none"
                rows={4}
              />
              <div className="flex gap-3">
                <Button
                  className="gap-2"
                  style={{
                    backgroundColor: accentColorMap[accentColor],
                    color: '#0f1a2e',
                  }}
                  disabled={!comment.trim()}
                >
                  Post Comment
                </Button>
                <Button variant="outline">Preview</Button>
              </div>
            </Card>

            {/* Recent Comments Display */}
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {showComments ? 'Recent comments:' : 'No comments yet. Be the first to share your thoughts!'}
              </p>
              {showComments && (
                <div className="space-y-3">
                  {[1, 2].map((i) => (
                    <Card key={i} className="bg-card/30 backdrop-blur-sm border-border p-4">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xs font-bold text-primary-foreground">
                          U{i}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-sm text-foreground">User {i}</p>
                          <p className="text-sm text-foreground/70 mt-1">
                            This is a sample comment demonstrating the community engagement feature.
                          </p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
