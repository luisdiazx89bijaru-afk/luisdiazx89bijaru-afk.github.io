import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ArticleProvider } from "./contexts/ArticleContext";
import { SearchProvider } from "./contexts/SearchContext";
import Home from "./pages/Home";
import Admin from "./pages/Admin";
import SearchResults from "./pages/SearchResults";


function Router() {
  return (
    <Switch>
      <Route path={"//"} component={Home} />
      <Route path={"/search"} component={SearchResults} />
      <Route path={"/admin"} component={Admin} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <ArticleProvider>
          <SearchProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </SearchProvider>
        </ArticleProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
