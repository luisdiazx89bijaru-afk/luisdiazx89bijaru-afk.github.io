# WORLD NEXUS - Admin Dashboard Guide

## Overview

The Admin Dashboard is a powerful publisher panel that allows you to manage articles directly from the web interface without touching code. All articles are stored locally in your browser using localStorage and persist across sessions.

## Accessing the Admin Dashboard

### URL
Navigate to: `/admin` on your WORLD NEXUS website

### Authentication
**Default Password**: `nexus2026`

> **Security Note**: For production use, change this password in `client/src/pages/Admin.tsx` line 68 and implement proper backend authentication.

## Features

### 1. Publisher Panel - Create New Articles

#### Access
Click the **"+ New Article"** button in the Admin Dashboard header.

#### Form Fields

**Article Title** (Required)
- Enter a compelling, descriptive title for your article
- Examples: "Understanding Middle East Geopolitics in 2026", "The Council of Nicaea: Shaping Christian Doctrine"

**Category** (Required)
- Select one of four categories:
  - **International News & Geopolitics**: Global affairs, conflicts, diplomatic relations
  - **Religions & Traditional Perspectives**: Religious traditions, philosophy, spirituality
  - **Global Politics & Finance**: Economics, financial systems, policy analysis
  - **The Daily AI Revolution & Tech Automation**: AI, technology, automation, future trends

**Author** (Required)
- Default: "WORLD NEXUS Editorial"
- Change to your name or organization

**Video Embed Link** (Optional)
- Paste full embed URLs from:
  - YouTube: `https://www.youtube.com/embed/VIDEO_ID`
  - Vimeo: `https://vimeo.com/VIDEO_ID`
- Videos appear below article content on the home page

**Article Content** (Required)
- Minimum 100 characters
- Write your full article text here
- Supports plain text formatting
- First 150 characters automatically become the excerpt

#### Publishing
1. Fill all required fields
2. Click **"Publish Article"** button
3. Article appears immediately on the home page in its category section
4. Success! Your article is now live

### 2. Article Management - Edit & Delete

#### View Published Articles
All published articles appear in a grid below the Publisher Panel, organized by category.

#### Edit Article
1. Click the **Edit** button (pencil icon) on any article card
2. The article form populates with existing content
3. Make your changes
4. Click **"Update Article"** to save
5. Changes appear immediately on the site

#### Delete Article
1. Click the **Delete** button (trash icon) on any article card
2. Confirm deletion in the popup dialog
3. Article is permanently removed
4. **Note**: This action cannot be undone

### 3. Category Filtering

Use the category filter buttons to view articles by type:
- **All Articles**: Show all published articles
- **International News & Geopolitics**: Filter by geopolitics category
- **Religions & Traditional Perspectives**: Filter by religion/philosophy
- **Global Politics & Finance**: Filter by politics/finance
- **The Daily AI Revolution & Tech Automation**: Filter by AI/tech

### 4. Dashboard Statistics

View key metrics at the bottom of the Admin Dashboard:
- **Total Articles**: Total number of published articles
- **Featured**: Articles marked as featured
- **With Videos**: Articles that include video embeds
- **Categories**: Number of active content categories

## Data Storage

### localStorage
All articles are stored in your browser's localStorage under the key `world-nexus-articles`.

**Capacity**: ~5-10MB depending on browser
**Persistence**: Data persists across browser sessions and page reloads
**Backup**: Manually export articles or use browser developer tools to backup localStorage

### Exporting Articles
To backup your articles:

1. Open browser DevTools (F12 or Cmd+Option+I)
2. Go to **Application** → **Local Storage** → **Your Domain**
3. Find `world-nexus-articles`
4. Copy the JSON value
5. Save to a text file for backup

### Importing Articles
To restore from backup:

1. Open browser DevTools
2. Go to **Application** → **Local Storage** → **Your Domain**
3. Click on `world-nexus-articles`
4. Paste your backed-up JSON
5. Refresh the page

## Article Display on Home Page

### Where Articles Appear
Each article category has its own section on the home page:

1. **International News Section**
   - Displays articles from "International News & Geopolitics" category
   - Shows article cards in a 2-column grid
   - Includes edit/delete controls in admin view

2. **Religions Section**
   - Displays articles from "Religions & Traditional Perspectives" category
   - Same layout and functionality

3. **Politics & Finance Section**
   - Displays articles from "Global Politics & Finance" category
   - Same layout and functionality

4. **AI Revolution Section**
   - Displays articles from "The Daily AI Revolution & Tech Automation" category
   - Same layout and functionality

### Article Card Display
Each published article shows:
- **Title**: Large, bold heading
- **Category Badge**: Color-coded label (cyan, gold, or crimson)
- **Featured Badge**: If marked as featured
- **Excerpt**: First 150 characters of content
- **Metadata**: Publication date, author, video indicator
- **Video Preview**: Embedded video player (if included)

## Best Practices

### Writing Effective Articles

**Title**
- Keep titles clear and descriptive (50-80 characters ideal)
- Use active language
- Include relevant keywords

**Content**
- Start with a compelling introduction
- Use clear paragraph breaks
- Include key takeaways or conclusions
- Aim for 300-1000 words for depth

**Video Embedding**
- Use embed URLs, not watch/share URLs
- Test the embed before publishing
- Ensure video is publicly accessible
- Provide context around the video in your article

**Category Selection**
- Choose the most relevant category
- Avoid cross-category articles (pick one)
- Use consistent categorization for better organization

### Managing Your Content

**Regular Updates**
- Review and update articles periodically
- Edit for clarity and accuracy
- Add new information as it emerges

**Consistency**
- Maintain consistent author attribution
- Use similar formatting across articles
- Keep article length reasonable

**Organization**
- Use meaningful titles for easy searching
- Organize by category logically
- Delete outdated or irrelevant articles

## Troubleshooting

### Article Not Appearing
**Problem**: Published article doesn't show on home page

**Solutions**:
1. Refresh the page (Cmd+R or Ctrl+R)
2. Check that you selected the correct category
3. Verify the article content is not empty
4. Clear browser cache and reload

### Lost Articles
**Problem**: Articles disappeared after browser restart

**Solutions**:
1. Check localStorage is enabled in browser settings
2. Restore from backup if available
3. Check browser's private/incognito mode (data not persisted)
4. Try a different browser

### Edit Button Not Working
**Problem**: Edit button doesn't respond

**Solutions**:
1. Refresh the admin page
2. Log out and log back in
3. Clear browser cache
4. Try a different browser

### Password Issues
**Problem**: Can't access admin dashboard

**Solutions**:
1. Verify password is exactly: `nexus2026`
2. Check caps lock is off
3. Clear browser cookies and try again
4. Contact site administrator if password was changed

## Security Considerations

### Current Implementation
- Password stored in client-side code (demo only)
- Data stored in browser localStorage (not encrypted)
- No backend authentication or authorization

### For Production Use

**Recommended Upgrades**:
1. **Backend Authentication**: Implement proper user authentication with secure password hashing
2. **Database Storage**: Move articles to a backend database (upgrade to web-db-user feature)
3. **Access Control**: Implement role-based access control (admin, editor, viewer)
4. **Encryption**: Encrypt sensitive data in transit and at rest
5. **Audit Logging**: Track who made changes and when

**To Upgrade to Full Backend**:
```bash
# In project directory
webdev_add_feature web-db-user
```

This will add:
- Backend server with Express.js
- Database integration (PostgreSQL)
- Proper authentication system
- Persistent article storage
- Multi-user support

## Advanced Features

### Batch Operations
Currently not available. To implement:
- Select multiple articles
- Bulk edit categories
- Bulk delete with confirmation

### Article Scheduling
Currently not available. To implement:
- Schedule articles for future publication
- Auto-publish at specific times
- Draft/published status

### Article Analytics
Currently not available. To implement:
- Track article views
- Monitor engagement metrics
- Popular articles dashboard

### Multi-User Support
Currently not available. To implement:
- Multiple admin accounts
- Contributor roles
- Article approval workflow

## Keyboard Shortcuts

Coming soon! Planned shortcuts:
- `Cmd/Ctrl + K`: Quick article search
- `Cmd/Ctrl + N`: New article
- `Cmd/Ctrl + S`: Save article
- `Escape`: Close editor

## API Reference

### useArticles Hook

```typescript
import { useArticles } from '@/contexts/ArticleContext';

const {
  articles,              // Array of all articles
  addArticle,            // (formData) => Article
  updateArticle,         // (id, formData) => boolean
  deleteArticle,         // (id) => boolean
  getArticleById,        // (id) => Article | undefined
  getArticlesByCategory, // (category) => Article[]
  clearAllArticles,      // () => void
} = useArticles();
```

### Article Type

```typescript
interface Article {
  id: string;                    // Unique identifier (nanoid)
  title: string;                 // Article title
  category: ArticleCategory;     // Content category
  content: string;               // Full article text
  videoEmbedUrl?: string;        // Optional video embed URL
  author: string;                // Author name
  createdAt: Date;               // Creation timestamp
  updatedAt: Date;               // Last update timestamp
  excerpt?: string;              // Auto-generated preview
  featured?: boolean;            // Featured status
}
```

## Support & Feedback

For issues, feature requests, or feedback:
- **Email**: contact@worldnexushistory.com
- **Website**: worldnexushistory.com

## Version History

- **v1.0.0** (May 2026): Initial Admin Dashboard release
  - Article CRUD operations
  - Category management
  - localStorage persistence
  - Password-protected access
  - Article filtering and statistics
