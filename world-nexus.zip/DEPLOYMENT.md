# WORLD NEXUS - Deployment & Development Guide

## Project Overview

**WORLD NEXUS** is a premium, interactive media and blogging platform featuring four main content pillars:

1. **International News & Geopolitics** - Analysis of global affairs and geopolitical dynamics
2. **Religions & Traditional Perspectives** - Exploration of spiritual wisdom and philosophical traditions
3. **Global Politics & Finance** - Understanding economic systems and their political implications
4. **The Daily AI Revolution & Tech Automation** - Coverage of artificial intelligence and technological transformation

## Design Philosophy: Digital Futurism with Historical Depth

The platform combines cutting-edge web technology with deep historical and philosophical aesthetics:

- **Color Palette**: Deep indigo (#0f1a2e) background, neon cyan (#00d9ff) for tech elements, crimson (#8b1a1a) for historical content, gold (#d4af37) for philosophical accents
- **Typography**: Space Mono (display), Lato (body), IBM Plex Mono (code/quotes)
- **Visual Effects**: Glassmorphism, diagonal accent bars, smooth animations, parallax scrolling
- **Interactive Elements**: Rotating philosophical quotes, video placeholders, community engagement features

## Technology Stack

- **Frontend**: React 19 with TypeScript
- **Styling**: Tailwind CSS 4 with custom theme variables
- **UI Components**: shadcn/ui component library
- **Routing**: Wouter (lightweight client-side routing)
- **Build Tool**: Vite
- **Deployment**: GitHub Pages or Manus hosting

## Project Structure

```
world-nexus/
├── client/
│   ├── public/              # Static configuration files
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── Navigation.tsx
│   │   │   ├── Hero.tsx
│   │   │   ├── ContentPillar.tsx
│   │   │   ├── Newsletter.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── ui/          # shadcn/ui components
│   │   ├── pages/           # Page-level components
│   │   │   ├── Home.tsx
│   │   │   └── NotFound.tsx
│   │   ├── contexts/        # React contexts
│   │   ├── hooks/           # Custom React hooks
│   │   ├── lib/             # Utility functions
│   │   ├── App.tsx          # Main app component with routing
│   │   ├── main.tsx         # React entry point
│   │   └── index.css        # Global styles and theme variables
│   └── index.html           # HTML template
├── server/                  # Backend server (Express)
├── shared/                  # Shared types and constants
└── package.json             # Dependencies and scripts
```

## Key Features

### 1. Premium Navigation
- Sticky header with glassmorphism effect
- Responsive mobile menu
- Smooth hover animations with gradient underlines
- Clear visual hierarchy with dividers

### 2. Hero Section
- Full-screen background with layered overlays
- Rotating philosophical quotes (6-second rotation)
- Smooth fade transitions between quotes
- Interactive quote indicator dots
- Animated scroll indicator

### 3. Content Pillars
- Four distinct sections with unique background imagery
- Glassmorphism card design for content
- Web-book reading layout with blockquotes
- Video placeholder containers (ready for YouTube/Vimeo embeds)
- Community engagement section with comment forms

### 4. Interactive Features
- Newsletter subscription with success state
- Comment submission interface
- Hover effects and micro-interactions
- Smooth scroll animations

### 5. Footer
- Multi-column layout with navigation links
- Social media integration
- Collaboration contact information
- Copyright and attribution

## Development Workflow

### Local Development

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview

# Type checking
pnpm check

# Format code
pnpm format
```

### Environment Setup

The project uses Vite's built-in environment variables. Create a `.env.local` file for local development:

```env
VITE_APP_TITLE=WORLD NEXUS
VITE_APP_LOGO=https://path-to-logo.png
```

## Customization Guide

### Updating Content

All content is defined in the Home page component (`client/src/pages/Home.tsx`). To update:

1. **Hero Quotes**: Edit the `PHILOSOPHICAL_QUOTES` array in `client/src/components/Hero.tsx`
2. **Content Sections**: Modify the `ContentPillar` props in `Home.tsx`
3. **Navigation Items**: Update the `navItems` array in `client/src/components/Navigation.tsx`

### Changing Colors

All colors are defined as CSS variables in `client/src/index.css`. Update the `:root` and `.dark` sections:

```css
:root {
  --primary: #00d9ff;           /* Neon cyan */
  --secondary: #8b1a1a;         /* Crimson */
  --accent: #d4af37;            /* Gold */
  --background: #0f1a2e;        /* Deep indigo */
  --foreground: #f5f5f5;        /* Bright white */
}
```

### Embedding Videos

Each content pillar has a video placeholder. To add actual videos:

1. Replace the placeholder component with an iframe:
```jsx
<iframe
  width="100%"
  height="400"
  src="https://www.youtube.com/embed/VIDEO_ID"
  title="Video Title"
  frameBorder="0"
  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
  allowFullScreen
/>
```

2. Or use Vimeo/other providers with similar embed code

### Adding New Pages

1. Create a new component in `client/src/pages/`
2. Add a route in `client/src/App.tsx`:
```tsx
<Route path="/new-page" component={NewPage} />
```
3. Update navigation in `Navigation.tsx`

## Deployment Options

### Option 1: Manus Hosting (Recommended)

The project is already configured for Manus hosting:

1. Click the "Publish" button in the Manus UI
2. Choose your domain (auto-generated or custom)
3. Deploy with one click

**Benefits**: Automatic SSL, CDN, analytics, custom domains, no configuration needed

### Option 2: GitHub Pages

To deploy to GitHub Pages:

1. **Update vite.config.ts** to set the base path:
```typescript
export default defineConfig({
  base: '/world-nexus/', // Replace with your repo name
  // ... rest of config
})
```

2. **Build the project**:
```bash
pnpm build
```

3. **Create GitHub Actions workflow** (`.github/workflows/deploy.yml`):
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: pnpm/action-setup@v2
      - uses: actions/setup-node@v3
        with:
          node-version: '22'
          cache: 'pnpm'
      - run: pnpm install
      - run: pnpm build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist/public
```

4. **Push to GitHub** and enable GitHub Pages in repository settings

### Option 3: Other Hosting Providers

The `dist/public` directory contains the production build. Deploy it to:
- Vercel: `vercel deploy`
- Netlify: Drag and drop `dist/public`
- AWS S3 + CloudFront
- Any static hosting service

## Performance Optimization

### Current Optimizations
- Vite code splitting for faster initial load
- CSS minification and optimization
- Image compression (using .webp format)
- Lazy loading for images

### Future Optimizations
- Implement route-based code splitting
- Add service worker for offline support
- Optimize bundle size (currently ~585KB)
- Implement image lazy loading

## SEO Configuration

Update `client/index.html` with proper meta tags:

```html
<meta name="description" content="WORLD NEXUS - Media platform bridging contemporary global issues with deep historical and philosophical understanding." />
<meta name="keywords" content="geopolitics, religion, finance, AI, technology, philosophy" />
<meta property="og:title" content="WORLD NEXUS" />
<meta property="og:description" content="Bridging contemporary global issues with deep historical and philosophical understanding." />
<meta property="og:image" content="https://path-to-og-image.png" />
```

## Analytics Integration

The project includes Umami analytics. Configure in `client/index.html`:

```html
<script
  defer
  src="https://your-umami-instance.com/script.js"
  data-website-id="YOUR_WEBSITE_ID"
></script>
```

## Troubleshooting

### Build Errors
- Clear cache: `rm -rf node_modules .pnpm-store dist`
- Reinstall: `pnpm install`
- Check Node version: `node --version` (should be 22.x)

### Styling Issues
- Verify CSS variables in `index.css`
- Check Tailwind configuration in `tailwind.config.ts`
- Clear browser cache (Cmd+Shift+Delete)

### Image Not Loading
- Verify image URL is correct
- Check CORS headers if using external images
- Use compressed .webp format for better performance

## Browser Support

- Chrome/Edge: Latest 2 versions
- Firefox: Latest 2 versions
- Safari: Latest 2 versions
- Mobile browsers: iOS Safari 14+, Chrome Android

## Accessibility

The project follows WCAG 2.1 AA standards:
- Semantic HTML structure
- Keyboard navigation support
- Color contrast ratios meet standards
- Focus indicators visible
- Alt text for images

## Security

- No sensitive data stored in frontend
- HTTPS enforced (via hosting provider)
- Content Security Policy headers recommended
- Regular dependency updates via `pnpm audit`

## Contact & Collaboration

For partnerships, media inquiries, and collaborations:

**Email**: contact@worldnexushistory.com  
**Website**: worldnexushistory.com

## License

© 2026 WORLD NEXUS. All rights reserved.

## Support

For technical issues and feature requests, refer to the project repository or contact the development team.
